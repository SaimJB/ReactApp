import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    hmr: {
      overlay: false, // Optional: Disable overlay for less disruption
    },
    // middlewareMode: 'ssr',
    // middleware: [
    //   (req, res, next) => {
    //     try {
    //       console.log('Request URL:', decodeURI(req.url));
    //     } catch (e) {
    //       // console.error('Malformed URI:', req.url);
    //     }
    //     next();
    //   }
    // ]
  },

})
